# weather-modeling
Python implementation of weather modeling using quadratic equations.
